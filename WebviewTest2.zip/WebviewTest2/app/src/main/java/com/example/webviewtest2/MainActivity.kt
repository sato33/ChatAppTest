package com.example.webviewtest2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView

import android.content.pm.PackageManager

import android.app.Activity
import android.webkit.WebChromeClient.FileChooserParams

import android.webkit.ValueCallback

import android.os.Build

import android.annotation.TargetApi
import android.net.Uri

import android.webkit.WebChromeClient
import androidx.core.app.ActivityCompat.startActivityForResult

import android.os.Parcelable

import android.content.Intent

import android.provider.MediaStore
import androidx.core.content.FileProvider

import android.os.Environment
import androidx.annotation.Nullable
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*


class MainActivity : AppCompatActivity() {
    private val REQUEST_SELECT_FILE_CODE: Int = 1001
    private var mImageUri: Uri? = null
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val webView = findViewById<WebView>(R.id.webView)

        webView.settings.javaScriptEnabled = true;
        webView.settings.domStorageEnabled = true;

        webView.webChromeClient = object : WebChromeClient() {
            @TargetApi(Build.VERSION_CODES.LOLLIPOP)
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                showFileChooser(filePathCallback, fileChooserParams)
                return true
            }
        }

//        webView.loadUrl("https://developer.mozilla.org/ja/docs/Web/HTML/Element/input/file")
        webView.loadUrl("file:///android_asset/index.html")

//        CheckPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE, 1000)
//        CheckPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE, 1000)
//        CheckPermission(this, Manifest.permission.CAMERA, 1001)
    }

//    fun CheckPermission(activity: Activity?, permission: String, requestCode: Int): Boolean {
//        // 権限の確認
//        if (ActivityCompat.checkSelfPermission(activity!!, permission) !=
//            PackageManager.PERMISSION_GRANTED
//        ) {
//            // 権限の許可を求めるダイアログを表示する
//            ActivityCompat.requestPermissions(activity, arrayOf(permission), requestCode)
//            return false
//        }
//        return true
//    }

    fun showFileChooser(
        filePathCallback: ValueCallback<Array<Uri>>?,
        fileChooserParams: FileChooserParams?
    ) {
        // 完了していない処理があれば完了する
//        if (filePathCallback != null) {
//            filePathCallback.onReceiveValue(null)
//        }
        this.filePathCallback = filePathCallback

//        // 権限がないときは、権限を要求する
//        if (!CameraPermission.checkAndRequestPermissions(this, REQUEST_PERMISSIONS)) {
//            filePathCallback.onReceiveValue(null)
//            filePathCallback = null
//            return
//        }

        // カメラとファイルのインテントを作成する
        val chooserIntent = Intent.createChooser(fileChooserParams?.createIntent(), "写真の選択")
        try {
            mImageUri = createImageFile()
            val imageCaptureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            imageCaptureIntent.putExtra(MediaStore.EXTRA_OUTPUT, mImageUri)
            chooserIntent.putExtra(
                Intent.EXTRA_INITIAL_INTENTS,
                arrayOf<Parcelable>(imageCaptureIntent)
            )
        } catch (ex: IOException) {
            mImageUri = null
        }
        startActivityForResult(chooserIntent, REQUEST_SELECT_FILE_CODE)
    }

    @Throws(IOException::class)
    private fun createImageFile(): Uri? {
        val folder: File? = getExternalFilesDir(Environment.DIRECTORY_DCIM)
        val date: String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val fileName = String.format("MyApp_%s.jpg", date)
        val cameraFile = File(folder, fileName)
        return FileProvider.getUriForFile(
            this,
            applicationContext.packageName + ".fileprovider",
            cameraFile
        )
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, @Nullable data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_SELECT_FILE_CODE) {
            if (filePathCallback != null) {
                if (resultCode == RESULT_OK) {
                    var result = FileChooserParams.parseResult(resultCode, data)
                    if (result == null) {
                        result = arrayOf<Uri>(mImageUri!!)
                    }
                    filePathCallback!!.onReceiveValue(result)
                } else {
                    filePathCallback!!.onReceiveValue(null)
                }
                filePathCallback = null
            }
        }
    }
}